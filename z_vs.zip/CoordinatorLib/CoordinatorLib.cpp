// CoordinatorLib.cpp : Defines the functions for the static library.

