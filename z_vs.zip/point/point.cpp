#include "point.h"

point::point(int x1,int y1,int id1)
{
    x=x1;
    y=y1;
    id=id1;
}
