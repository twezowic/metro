#include "people.h"

people::people(int idstation1):idstation(idstation1)
{

};
void people::setroute(vector <station*> route1)
{
    myroute=route1;
}
