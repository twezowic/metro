#ifndef PEOPLE_H
#define PEOPLE_H
#include "../station/station.h"

class people
{int idstation;
  vector <station*>myroute;
public:
    people(int idstation1);
    void setroute(vector <station*>route1);
};

#endif // PEOPLE_H
