#pragma once
#include "station.h"
using namespace std;

#include <queue>
#include <vector>
#include <string>
station::station(string name1, int id1,timetable& v,int x1,int y1):point(x1,y1,id1)
{
    name = name1;
    mytimetable=&v;
}

string station::toString()
{
    return (name + " " + to_string(id));
}
void station::add_conection(one_wayconection& id)
{
    out_conection_vec.push_back(&id);
}
void station::remove_conection(one_wayconection id)
{
    int position = 0;
    for (auto i = out_conection_vec.begin(); i < out_conection_vec.end(); i++)
    {
        if (*i == &id)
        {
            position = i - out_conection_vec.begin();
        }
    }
    out_conection_vec.erase(out_conection_vec.begin() + position);
}
void  station::add_timetable(train& trainname, int time)
{
   mytimetable->add_timetable(trainname,time);
}
string station::nexttrain(int time)
{
    return mytimetable->nexttrain(time);
}
